package com.rohitsemriwal.ecommerce

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
